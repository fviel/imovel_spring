package br.com.amitta.real_state;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RealStateApplication {

	public static void main(String[] args) {
		SpringApplication.run(RealStateApplication.class, args);
	}

}
