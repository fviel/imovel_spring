package br.com.amitta.real_state;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RealStateApplicationTests {

	@Test
	void contextLoads() {
	}

}
